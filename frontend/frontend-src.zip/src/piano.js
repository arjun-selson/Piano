import React, { useRef, useState, useEffect } from 'react';
import Navbar1 from './Navbar1';
import './piano.css';

const recordIcons = [
  'https://www.flipsidexr.com/files/docs/graphics/button_w-record.png',
  'https://png.pngtree.com/element_our/png/20181205/stop-vector-icon-png_256694.jpg'
];

const keyMap = [
  // Block keys
  { id: 'button1', key: '1', label: 'C3#', audio: '/Key_Sounds/203466__tesabob2001__c3z.mp3', className: 'block-key-1' },
  { id: 'button2', key: '2', label: 'D3#', audio: '/Key_Sounds/203489__tesabobe2001__d3z.mp3', className: 'block-key-2' },
  { id: 'buttonA', key: 'a', label: 'F3#', audio: '/Key_Sounds/203501__tesabob2001__f3z.mp3', className: 'block-key-a' },
  { id: 'buttonS', key: 's', label: 'G3#', audio: '/Key_Sounds/203488__tesabob2001__g3z.mp3', className: 'block-key-s' },
  { id: 'buttonD', key: 'd', label: 'A3#', audio: '/Key_Sounds/203502__tesabob2001__a3z.mp3', className: 'block-key-d' },
  { id: 'buttonF', key: 'f', label: 'C3#', audio: '/Key_Sounds/203481__tesabob2001__c4z.mp3', className: 'block-key-f' },
  { id: 'buttonG', key: 'g', label: 'D4#', audio: '/Key_Sounds/203482__tesabob2001__d4z.mp3', className: 'block-key-g' },
  { id: 'buttonH', key: 'h', label: 'F4#', audio: '/Key_Sounds/203500__tesabob2001__f4.mp3', className: 'block-key-h' },
  { id: 'buttonJ', key: 'j', label: 'G4#', audio: '/Key_Sounds/203491__tesabob2001__g4z.mp3', className: 'block-key-j' },
  { id: 'buttonK', key: 'k', label: 'A4#', audio: '/Key_Sounds/203460__tesabob2001__a4z.mp3', className: 'block-key-k' },
  { id: 'buttonL', key: 'l', label: 'C5#', audio: '/Key_Sounds/203480__tesabob2001__c5z.mp3', className: 'block-key-l' },
  { id: 'button;', key: ';', label: 'D5#', audio: '/Key_Sounds/203487__tesabob2001__d5z.mp3', className: 'block-key-;' },
  { id: 'button8', key: '8', label: 'F5#', audio: '/Key_Sounds/203499__tesabob2001__f5z.mp3', className: 'block-key-8' },
  { id: 'button9', key: '9', label: 'G5#', audio: '/Key_Sounds/203490__tesabob2001__g5z.mp3', className: 'block-key-9' },
  { id: 'button0', key: '0', label: 'A5#', audio: '/Key_Sounds/203459__tesabob2001__a5z.mp3', className: 'block-key-0' },
  // White keys
  { id: 'buttonQ', key: 'q', label: 'C3', audio: '/Key_Sounds/203479__tesabob2001__c3.mp3', className: 'white-key' },
  { id: 'buttonW', key: 'w', label: 'D3', audio: '/Key_Sounds/203486__tesabob2001__d3.mp3', className: 'white-key' },
  { id: 'buttonE', key: 'e', label: 'E3', audio: '/Key_Sounds/203470__tesabob2001__e3.mp3', className: 'white-key' },
  { id: 'buttonR', key: 'r', label: 'F3', audio: '/Key_Sounds/203468__tesabob2001__f3.mp3', className: 'white-key' },
  { id: 'buttonT', key: 't', label: 'G3', audio: '/Key_Sounds/203493__tesabob2001__g3.mp3', className: 'white-key' },
  { id: 'buttonY', key: 'y', label: 'A3', audio: '/Key_Sounds/203458__tesabob2001__a3.mp3', className: 'white-key' },
  { id: 'buttonU', key: 'u', label: 'B3', audio: '/Key_Sounds/203463__tesabob2001__b3.mp3', className: 'white-key' },
  { id: 'buttonI', key: 'i', label: 'C4', audio: '/Key_Sounds/203478__tesabob2001__c4.mp3', className: 'white-key' },
  { id: 'buttonO', key: 'o', label: 'D4', audio: '/Key_Sounds/203482__tesabob2001__d4.mp3', className: 'white-key' },
  { id: 'buttonP', key: 'p', label: 'E4', audio: '/Key_Sounds/203471__tesabob2001__e4.mp3', className: 'white-key' },
  { id: 'button[', key: '[', label: 'F4', audio: '/Key_Sounds/203500__tesabob2001__f4.mp3', className: 'white-key' },
  { id: 'button]', key: ']', label: 'G4', audio: '/Key_Sounds/203492__tesabob2001__g4.mp3', className: 'white-key' },
  { id: 'buttonZ', key: 'z', label: 'A4', audio: '/Key_Sounds/203465__tesabob2001__a4.mp3', className: 'white-key' },
  { id: 'buttonX', key: 'x', label: 'B4', audio: '/Key_Sounds/203462__tesabob2001__b4.mp3', className: 'white-key' },
  { id: 'buttonC', key: 'c', label: 'C5', audio: '/Key_Sounds/203485__tesabob2001__c5.mp3', className: 'white-key' },
  { id: 'buttonV', key: 'v', label: 'D5', audio: '/Key_Sounds/203473__tesabob2001__d5.mp3', className: 'white-key' },
  { id: 'buttonB', key: 'b', label: 'E5', audio: '/Key_Sounds/203476__tesabob2001__e5.mp3', className: 'white-key' },
  { id: 'buttonN', key: 'n', label: 'F5', audio: '/Key_Sounds/203489__tesabob2001__f5.mp3', className: 'white-key' },
  { id: 'buttonM', key: 'm', label: 'G5', audio: '/Key_Sounds/203495__tesabob2001__g5.mp3', className: 'white-key' },
  { id: 'button,', key: ',', label: 'A5', audio: '/Key_Sounds/203464__tesabob2001__a5.mp3', className: 'white-key' },
  { id: 'button.', key: '.', label: 'B5', audio: '/Key_Sounds/203467__tesabob2001__b5.mp3', className: 'white-key' },
  { id: 'button.', key: '1', label: 'B5', audio: '/Key_Sounds/203467__tesabob2001__b5.mp3', className: 'white-key' }
];

const audioRefs = {};
const btnRefs = {};

const Piano = () => {
  const [recImg, setRecImg] = useState(recordIcons[0]);
  const [recording, setRecording] = useState(false);
  const [fileName, setFileName] = useState('');
  const [srcs, setSrcs] = useState([]);
  const [blobUrl, setBlobUrl] = useState(null);

  // Keydown event for all keys
  useEffect(() => {
    const handleKeyDown = (event) => {
      const key = typeof event.key === "string" ? event.key.toLowerCase() : event.key;
      const found = keyMap.find(k => k.key === key);
      if (found) {
        handleButtonClick(found.id);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  // Play audio and animate key
  const handleButtonClick = async (btnId) => {
  const found = keyMap.find(k => k.id === btnId);
  const audio = audioRefs[btnId];
  if (audio) {
    audio.currentTime = 0;
    audio.play();
    // Animation
    const btn = btnRefs[btnId];
    if (btn) {
      btn.classList.add('pressed');
      setTimeout(() => {
        btn.classList.remove('pressed');
      }, 150);
    }
    // Recording
    if (recording) {
      setSrcs(prev => [...prev, found.audio]);
    }
  }
};
  

  // Start/stop recording and build blob
  const changePic = async () => {
    if (!recording) {
      setRecImg(recordIcons[1]);
      setRecording(true);
      setSrcs([]);
      setBlobUrl(null);
    } else {
      setRecImg(recordIcons[0]);
      setRecording(false);
      // Fetch all blobs and merge
      const proms = srcs.map(uri =>
        fetch(uri).then(r => r.blob())
      );
      const blobs = await Promise.all(proms);
      const merged = new Blob(blobs, { type: "audio/mp3" });
      const url = URL.createObjectURL(merged);
      setBlobUrl(url);
    }
  };
  useEffect(() => {
  const handleKeyDown = (event) => {
    const key = typeof event.key === "string" ? event.key.toLowerCase() : event.key;
    const found = keyMap.find(k => k.key === key);
    if (found) {
      handleButtonClick(found.id);
    }
  };
  window.addEventListener('keydown', handleKeyDown);
  return () => window.removeEventListener('keydown', handleKeyDown);
}, [recording, srcs]);


  // Download merged mp3
  const down = (e) => {
    e.preventDefault();
    if (!blobUrl) return;
    const downloadLink = document.createElement('a');
    downloadLink.href = blobUrl;
    downloadLink.download = (fileName || "recording") + ".mp3";
    downloadLink.click();
    URL.revokeObjectURL(blobUrl);
    setBlobUrl(null);
  };

  return (
    <>
      <Navbar1 />
      <div className="main-contents">
        <div className="topic">
          <div style={{ float: 'left', width: 750 }}>
            <p style={{ fontWeight: 'bold', color: 'rgb(168, 115, 218)', fontSize: 18, fontFamily: 'Dancing Script, cursive' }}>
              Welcome to Pianist!
            </p>
            <p style={{ lineHeight: 1.5 }}>
              Welcome to Pianist! Our Virtual Piano lets you play on your computer or laptop keyboard.
              Enjoy a special feature: registered users can <i>download music</i>, enhancing skills and musical enjoyment.
            </p>
          </div>
          <div className="record" style={{ float: 'right', textAlign: 'center', lineHeight: 1.5 }}>
            <button id="topic_button" onClick={changePic} style={{ background: 'none', border: 'none' }}>
              <img src={recImg} style={{ height: 45, width: 75 }} id="recimg" alt="Record" />
            </button>
            <form onSubmit={down}>
              <label>Enter File Name:</label><br />
              <input
                type="text"
                id="fname"
                style={{ width: 120, border: '2px solid black' }}
                placeholder="   Audio file name"
                value={fileName}
                onChange={e => setFileName(e.target.value)}
              /><br />
              <button
                id="download"
                style={{ width: 125, backgroundColor: '#00cc00', borderRadius: 3, padding: 4, marginTop: 5, border: 'none' }}
                disabled={!blobUrl}
                type="submit"
              >
                Download
              </button>
            </form>
          </div>
        </div>
        <br>

        </br>
        <br>
        </br>
        <div className="keys">
          <div id="block-keys">
            {keyMap.filter(k => k.className.startsWith('block-key')).map(k => (
              <button
                key={k.id}
                id={k.id}
                className={k.className}
                ref={el => btnRefs[k.id] = el}
                onClick={() => handleButtonClick(k.id)}
              >
                <b>{k.key}<br /><br />{k.label}</b>
                <audio ref={el => audioRefs[k.id] = el} id={`audio_${k.key}`} src={k.audio}></audio>
              </button>
            ))}
          </div>
          <div id="white-keys">
            {keyMap.filter(k => k.className === 'white-key').map(k => (
              <button
                key={k.id}
                id={k.id}
                className={k.className}
                ref={el => btnRefs[k.id] = el}
                onClick={() => handleButtonClick(k.id)}
              >
                <b>{k.key}<br /><br />{k.label}</b>
                <audio ref={el => audioRefs[k.id] = el} id={`audio_${k.key}`} src={k.audio}></audio>
              </button>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Piano;