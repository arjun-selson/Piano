import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Navbar from './Navbar';
import Login from './Login';
import SignUp from './Signup';
import Piano from './piano';
import Navbar1 from './Navbar1';
// import other pages/components as needed

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path ="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path ="/myhome" element = {<Piano/>} />
      </Routes>
    </Router>
  );
}

export default App;